from cv2 import cv2
import os
import numpy as np 
import FaceRecognition as fr 

#This module take images stored in disk and perform face detection

test_img= cv2.imread("E:/Jarvis/mini project/faceRecognition_master/TestImages/Ronak.jpg")

faces_detected,gray_img = fr.faceDetection(test_img)
print("faceDetected: ",faces_detected)

filename = os.listdir("E:/Jarvis/mini project/faceRecognition_master/TrainingModle")
if 'trainingData.yml' in filename:
    print("Skipping Training Modle Creation")
    face_recognizer = fr.useTrainingModle()
else:
    print("Creating Training Modle....")
    face_recognizer = fr.createTrainingModle()

for face in faces_detected:
    (x,y,w,h) = face
    roi_gray = gray_img[y:y+h,x:x+h]
    label,confidence = face_recognizer.predict(roi_gray)
    confidence =np.absolute(confidence-100) 
    print("confidence: ",confidence)
    print("label ",fr.name[label] )
    fr.draw_rect(test_img,face)
    predicted_name = fr.name[label]
    if(confidence<40):
        continue
    fr.put_text(test_img,predicted_name,x,y)
resized_img = cv2.resize(test_img,(1000,1000))
cv2.imshow("faces detection tutorial",resized_img)
cv2.waitKey(0)
cv2.destroyAllWindows()    
